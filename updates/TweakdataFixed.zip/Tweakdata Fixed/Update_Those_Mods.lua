if UpdateThisMod then
	UpdateThisMod:Add({
		mod_id = 'Tweakdata fixed',
		data = {
			modworkshop_id = 21098,
			dl_url = "https://github.com/PJzuza/Hassat_TweakdataFixed/raw/master/updates/TweakdataFixed.zip", 
			info_url = "https://github.com/PJzuza/Hassat_TweakdataFixed/raw/master/mod.txt"
		}
	})
end